import io
import json

from fdk import response
import sys
sys.path.append('/function')
import score

model = score.load_model()

def handler(ctx, data: io.BytesIO=None):

    input = json.loads(data.getvalue())['input']
    prediction = score.predict(input, model)


    return response.Response(
        ctx, response_data=json.dumps(prediction),
        headers={"Content-Type": "application/json"}
    )